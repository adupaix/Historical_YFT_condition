Run procedure
=============

Tue May 31 11:28:28 2022

1. On the IT cluster, run:
	- job_whole_dataset.pbs (main study)
	- job_fishing_mode.pbs (supplementary materials)
	- job_small.pbs (supplementary materials)
	- job_medium.pbs (supplementary materials)
	- job_large.pbs (supplementary materials)
Each "job_[suffixe].pbs" file is linked with a configuration file named "cfg_[suffixe].R"
Each one will generate an output directory named with the date of the run and the suffixe

2. On your computer, run:
	- cfg_build_figures.R

	- main_post_cluster.R : run 5 times, takes the output directory from step 1 as input.
	  Change 'study_date' and 'output_suffixe' parameters in the script to adapt to the 5 outputs obtained in step 1.
